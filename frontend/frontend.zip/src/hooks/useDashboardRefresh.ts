import { useQueryClient } from '@tanstack/react-query';
import { useCallback } from 'react';

/**
 * Dashboard query key prefixes — all dashboard queries start with 'dashboard'.
 * Invalidating ['dashboard'] will refetch every role's dashboard automatically.
 */
const DASHBOARD_QUERY_PREFIX = ['dashboard'];

/**
 * Hook that returns a function to invalidate all dashboard queries.
 * Call this after any mutation that would affect dashboard data:
 * leads CRUD, opportunities CRUD, activities CRUD, imports, etc.
 */
export function useDashboardRefresh() {
  const queryClient = useQueryClient();

  const refreshDashboard = useCallback(() => {
    queryClient.invalidateQueries({ queryKey: DASHBOARD_QUERY_PREFIX });
  }, [queryClient]);

  return refreshDashboard;
}

/**
 * Standalone function for use outside React components (e.g., in onSuccess callbacks).
 * Requires the queryClient to be passed in.
 */
export function invalidateDashboardQueries(queryClient: ReturnType<typeof useQueryClient>) {
  queryClient.invalidateQueries({ queryKey: DASHBOARD_QUERY_PREFIX });
}
