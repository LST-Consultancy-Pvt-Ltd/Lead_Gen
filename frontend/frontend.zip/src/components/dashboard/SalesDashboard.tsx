'use client';
import { useQuery } from '@tanstack/react-query';
import { dashboardApi } from '../../lib/api';
import { Spinner } from '../ui';
import { Users, Calendar, DollarSign, TrendingUp } from 'lucide-react';

function StatCard({ label, value, icon: Icon, color = 'blue' }: {
  label: string; value: string | number; icon: any; color?: string;
}) {
  const colors: Record<string, string> = {
    blue:   'from-blue-600/20 to-blue-600/5 border-blue-500/20 text-blue-400',
    green:  'from-emerald-600/20 to-emerald-600/5 border-emerald-500/20 text-emerald-400',
    purple: 'from-purple-600/20 to-purple-600/5 border-purple-500/20 text-purple-400',
    amber:  'from-amber-600/20 to-amber-600/5 border-amber-500/20 text-amber-400',
  };
  return (
    <div className={`card p-5 bg-gradient-to-br border ${colors[color]}`}>
      <div className="flex items-start justify-between mb-3">
        <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">{label}</p>
        <Icon size={16} className={colors[color].split(' ')[3]} />
      </div>
      <p className="text-2xl font-bold text-slate-100">{value}</p>
    </div>
  );
}

export function SalesDashboard() {
  const { data, isLoading } = useQuery({
    queryKey: ['dashboard-sales'],
    queryFn: () => dashboardApi.getSalesDashboard().then(r => r.data?.data ?? r.data),
    staleTime: 60_000,
  });

  if (isLoading) {
    return <div className="flex items-center justify-center py-24"><Spinner size={24} /></div>;
  }

  const d = data ?? {};
  const followUps: any[] = d.followUpsToday ?? [];
  const openOpportunities: any[] = d.openOpportunities ?? [];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="page-title">My Dashboard</h1>
        <p className="text-sm text-slate-500 mt-1">Your personal performance overview</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="My Leads"         value={d.myLeads ?? 0}           icon={Users}      color="blue" />
        <StatCard label="Follow-ups Today" value={d.followUpsTodayCount ?? followUps.length} icon={Calendar}   color="amber" />
        <StatCard label="Open Deals"       value={d.openDealsCount ?? openOpportunities.length} icon={TrendingUp} color="purple" />
        <StatCard label="Won Revenue"      value={`$${(d.wonRevenue ?? 0).toLocaleString()}`} icon={DollarSign} color="green" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Follow-ups today */}
        <div className="card overflow-hidden">
          <div className="px-5 py-4 border-b border-white/[0.06] flex items-center gap-2">
            <Calendar size={15} className="text-amber-400" />
            <h2 className="section-title">Follow-ups Due Today</h2>
          </div>
          {followUps.length === 0 ? (
            <p className="text-sm text-slate-500 px-5 py-8 text-center">No follow-ups due today ✅</p>
          ) : (
            <ul className="divide-y divide-white/[0.04]">
              {followUps.map((lead: any) => (
                <li key={lead.id} className="px-5 py-3 hover:bg-slate-800/20">
                  <p className="text-sm font-medium text-slate-200">{lead.companyName}</p>
                  <p className="text-xs text-slate-500">{lead.contactName ?? lead.contactEmail}</p>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* Open Opportunities */}
        <div className="card overflow-hidden">
          <div className="px-5 py-4 border-b border-white/[0.06] flex items-center gap-2">
            <TrendingUp size={15} className="text-purple-400" />
            <h2 className="section-title">My Open Opportunities</h2>
          </div>
          {openOpportunities.length === 0 ? (
            <p className="text-sm text-slate-500 px-5 py-8 text-center">No open opportunities yet</p>
          ) : (
            <ul className="divide-y divide-white/[0.04]">
              {openOpportunities.map((opp: any) => (
                <li key={opp.id} className="px-5 py-3 hover:bg-slate-800/20">
                  <p className="text-sm font-medium text-slate-200">{opp.opportunityName}</p>
                  <p className="text-xs text-slate-500">
                    Stage: <span className="text-purple-400">{opp.stage}</span> ·
                    ${(opp.dealValue ?? 0).toLocaleString()}
                  </p>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}
