'use client';
import { useQuery } from '@tanstack/react-query';
import { dashboardApi } from '../../lib/api';
import { Spinner } from '../ui';
import { TrendingUp, DollarSign, Users, BarChart3, Target, Percent } from 'lucide-react';

function StatCard({ label, value, sub, icon: Icon, color = 'blue' }: {
  label: string; value: string | number; sub?: string; icon: any; color?: string;
}) {
  const colors: Record<string, string> = {
    blue: 'from-blue-600/20 to-blue-600/5 border-blue-500/20 text-blue-400',
    green: 'from-emerald-600/20 to-emerald-600/5 border-emerald-500/20 text-emerald-400',
    purple: 'from-purple-600/20 to-purple-600/5 border-purple-500/20 text-purple-400',
    amber: 'from-amber-600/20 to-amber-600/5 border-amber-500/20 text-amber-400',
  };
  return (
    <div className={`card p-5 bg-gradient-to-br border ${colors[color]}`}>
      <div className="flex items-start justify-between mb-3">
        <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">{label}</p>
        <Icon size={16} className={colors[color].split(' ')[3]} />
      </div>
      <p className="text-2xl font-bold text-slate-100">{value}</p>
      {sub && <p className="text-xs text-slate-500 mt-1">{sub}</p>}
    </div>
  );
}

export function CEODashboard() {
  const { data, isLoading } = useQuery({
    queryKey: ['dashboard-ceo'],
    queryFn: () => dashboardApi.getCEODashboard().then(r => r.data?.data ?? r.data),
    staleTime: 60_000,
  });

  if (isLoading) {
    return <div className="flex items-center justify-center py-24"><Spinner size={24} /></div>;
  }

  const d = data ?? {};
  const roiBySource: any[] = d.roiBySource ?? [];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="page-title">CEO Dashboard</h1>
        <p className="text-sm text-slate-500 mt-1">Organization-wide overview</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        <StatCard label="Leads This Week"  value={d.leadsThisWeek  ?? 0} icon={Users}     color="blue" />
        <StatCard label="Leads This Month" value={d.leadsThisMonth ?? 0} icon={TrendingUp} color="blue" />
        <StatCard label="Pipeline Value"   value={`$${(d.pipelineValue ?? 0).toLocaleString()}`} icon={BarChart3} color="purple" />
        <StatCard label="Closed Revenue"   value={`$${(d.closedRevenue ?? 0).toLocaleString()}`} icon={DollarSign} color="green" />
        <StatCard label="Conversion Rate"  value={`${d.conversionRate ?? 0}%`} icon={Percent} color="amber" />
        <StatCard label="Total Leads"      value={d.totalLeads ?? 0} icon={Target} color="blue" />
      </div>

      {roiBySource.length > 0 && (
        <div className="card overflow-hidden">
          <div className="px-5 py-4 border-b border-white/[0.06]">
            <h2 className="section-title">ROI by Lead Source</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-white/[0.06]">
                  {['Source', 'Leads', 'Revenue', 'Cost', 'ROI'].map(h => (
                    <th key={h} className="px-4 py-3 text-left text-[10px] font-semibold text-slate-500 uppercase tracking-wider">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {roiBySource.map((row: any, i: number) => (
                  <tr key={i} className="border-b border-white/[0.04] hover:bg-slate-800/20">
                    <td className="px-4 py-3 text-sm font-medium text-slate-200">{row.source}</td>
                    <td className="px-4 py-3 text-sm text-slate-400">{row.leads ?? 0}</td>
                    <td className="px-4 py-3 text-sm text-emerald-400">${(row.revenue ?? 0).toLocaleString()}</td>
                    <td className="px-4 py-3 text-sm text-slate-400">${(row.cost ?? 0).toLocaleString()}</td>
                    <td className="px-4 py-3 text-sm">
                      <span className={`font-semibold ${(row.roi ?? 0) >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                        {(row.roi ?? 0).toFixed(1)}x
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
