'use client';
import { useQuery } from '@tanstack/react-query';
import { dashboardApi } from '../../lib/api';
import { Spinner } from '../ui';
import { Users, AlertCircle, Clock } from 'lucide-react';
import { timeAgo } from '../../lib/utils';

export function ManagerDashboard() {
  const { data, isLoading } = useQuery({
    queryKey: ['dashboard-manager'],
    queryFn: () => dashboardApi.getManagerDashboard().then(r => r.data?.data ?? r.data),
    staleTime: 60_000,
  });

  if (isLoading) {
    return <div className="flex items-center justify-center py-24"><Spinner size={24} /></div>;
  }

  const d = data ?? {};
  const byExecutive: any[] = d.byExecutive ?? [];
  const stuckDeals: any[] = d.stuckDeals ?? [];
  const inactiveLeads: any[] = d.inactiveLeads ?? [];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="page-title">Manager Dashboard</h1>
        <p className="text-sm text-slate-500 mt-1">Team performance overview</p>
      </div>

      {/* Leads by Executive */}
      <div className="card overflow-hidden">
        <div className="px-5 py-4 border-b border-white/[0.06] flex items-center gap-2">
          <Users size={15} className="text-blue-400" />
          <h2 className="section-title">Leads by Sales Executive</h2>
        </div>
        {byExecutive.length === 0 ? (
          <p className="text-sm text-slate-500 px-5 py-8 text-center">No data yet</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-white/[0.06]">
                  {['Executive', 'Total Leads', 'Open', 'Won', 'Conversion'].map(h => (
                    <th key={h} className="px-4 py-3 text-left text-[10px] font-semibold text-slate-500 uppercase tracking-wider">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {byExecutive.map((row: any, i: number) => (
                  <tr key={i} className="border-b border-white/[0.04] hover:bg-slate-800/20">
                    <td className="px-4 py-3">
                      <p className="text-sm font-medium text-slate-200">{row.name}</p>
                      <p className="text-xs text-slate-500">{row.email}</p>
                    </td>
                    <td className="px-4 py-3 text-sm text-slate-400">{row.total ?? 0}</td>
                    <td className="px-4 py-3 text-sm text-slate-400">{row.open ?? 0}</td>
                    <td className="px-4 py-3 text-sm text-emerald-400">{row.won ?? 0}</td>
                    <td className="px-4 py-3 text-sm text-blue-400">{row.conversionRate ?? 0}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Stuck Deals */}
        <div className="card overflow-hidden">
          <div className="px-5 py-4 border-b border-white/[0.06] flex items-center gap-2">
            <AlertCircle size={15} className="text-amber-400" />
            <h2 className="section-title">Stuck Deals (&gt;14 days)</h2>
          </div>
          {stuckDeals.length === 0 ? (
            <p className="text-sm text-slate-500 px-5 py-8 text-center">No stuck deals 🎉</p>
          ) : (
            <ul className="divide-y divide-white/[0.04]">
              {stuckDeals.map((d: any) => (
                <li key={d.id} className="px-5 py-3 hover:bg-slate-800/20">
                  <p className="text-sm font-medium text-slate-200">{d.companyName ?? d.opportunityName}</p>
                  <p className="text-xs text-slate-500">Stage: <span className="text-amber-400">{d.stage}</span> · {d.daysSinceUpdate ?? 0} days</p>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* Inactive Leads */}
        <div className="card overflow-hidden">
          <div className="px-5 py-4 border-b border-white/[0.06] flex items-center gap-2">
            <Clock size={15} className="text-red-400" />
            <h2 className="section-title">No Activity (7+ days)</h2>
          </div>
          {inactiveLeads.length === 0 ? (
            <p className="text-sm text-slate-500 px-5 py-8 text-center">All leads are active 🎉</p>
          ) : (
            <ul className="divide-y divide-white/[0.04]">
              {inactiveLeads.map((lead: any) => (
                <li key={lead.id} className="px-5 py-3 hover:bg-slate-800/20">
                  <p className="text-sm font-medium text-slate-200">{lead.companyName}</p>
                  <p className="text-xs text-slate-500">
                    Owner: {lead.assignedTo?.name ?? 'Unassigned'} ·{' '}
                    Last activity: {lead.lastActivityAt ? timeAgo(lead.lastActivityAt) : 'Never'}
                  </p>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}
