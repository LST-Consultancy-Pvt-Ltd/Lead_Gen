'use client';

import { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { analyticsApi } from '../../lib/api';
import { Spinner } from '../../components/ui';
import { WidgetGrid, DateFilterBar, type DashboardWidget } from './DashboardWidgets';
import { startOfWeek, startOfMonth, subDays, startOfQuarter, format } from 'date-fns';

// ── Date Range Helper (shared with AdminDashboard) ─────────────────────────
export function getDateRange(preset: string) {
  const now = new Date();
  switch (preset) {
    case 'this_week':
      return { startDate: format(startOfWeek(now, { weekStartsOn: 1 }), 'yyyy-MM-dd'), endDate: format(now, 'yyyy-MM-dd') };
    case 'this_month':
      return { startDate: format(startOfMonth(now), 'yyyy-MM-dd'), endDate: format(now, 'yyyy-MM-dd') };
    case 'last_30':
      return { startDate: format(subDays(now, 30), 'yyyy-MM-dd'), endDate: format(now, 'yyyy-MM-dd') };
    case 'this_quarter':
      return { startDate: format(startOfQuarter(now), 'yyyy-MM-dd'), endDate: format(now, 'yyyy-MM-dd') };
    default:
      return {};
  }
}

/**
 * Normalizes manager API response → DashboardWidget[].
 * If backend already sends `widgets[]`, uses that directly.
 */
export function buildManagerWidgets(data: any): DashboardWidget[] {
  // Backend-driven: if the API already sends a widgets array, return it directly
  if (Array.isArray(data?.widgets)) {
    return data.widgets as DashboardWidget[];
  }

  const widgets: DashboardWidget[] = [];
  const teamPerformance = Array.isArray(data?.teamPerformance ?? data?.leadsByExecutive ?? data?.byExecutive)
    ? (data?.teamPerformance ?? data?.leadsByExecutive ?? data?.byExecutive)
    : [];

  // ── Widget 1: Revenue closed (period) ────────────────────────
  widgets.push({
    id: 'revenue_closed',
    type: 'currency_card',
    title: 'Revenue closed (period)',
    description: 'Total deal value of Closed Won in selected period',
    icon: 'dollar',
    color: 'emerald',
    layout: 'half',
    data: { value: data?.revenueClosed ?? data?.totalRevenueClosed ?? 0 },
  });

  // ── Widget 2: Revenue forecast (weighted) ────────────────────
  widgets.push({
    id: 'revenue_forecast',
    type: 'currency_card',
    title: 'Revenue forecast (weighted)',
    description: 'SUM(deal_value × probability) of open opportunities',
    icon: 'trending_up',
    color: 'violet',
    layout: 'half',
    data: { value: data?.revenueForecast ?? data?.weightedForecast ?? 0 },
  });

  // ── Widget 3: Leads by executive (bar chart) ─────────────────
  widgets.push({
    id: 'leads_by_executive',
    type: 'bar_chart',
    title: 'Leads by Executive',
    icon: 'bar_chart',
    color: 'blue',
    layout: 'half',
    data: {
      items: teamPerformance.map((e: any) => ({
        name: e.executiveName || e.name || '—',
        value: e.leadCount ?? e.total ?? e.leads ?? 0,
      })),
      dataKey: 'value',
      nameKey: 'name',
      barColor: '#3b82f6',
      barLabel: 'Leads',
    },
  });

  // ── Widget 4: Conversion rate by executive ───────────────────
  widgets.push({
    id: 'conversion_by_executive',
    type: 'bar_chart',
    title: 'Conversion Rate by Executive',
    icon: 'target',
    color: 'emerald',
    layout: 'half',
    data: {
      items: teamPerformance.map((e: any) => ({
        name: e.executiveName || e.name || '—',
        value: Number(e.conversionRate ?? e.conversion ?? 0),
      })),
      dataKey: 'value',
      nameKey: 'name',
      barColor: '#10b981',
      barLabel: 'Conversion Rate',
      isPercentage: true,
    },
  });

  // ── Widget 5: Pipeline by stage ──────────────────────────────
  const pipelineByStage = Array.isArray(data?.pipelineByStage ?? data?.pipeline)
    ? (data?.pipelineByStage ?? data?.pipeline)
    : [];
  widgets.push({
    id: 'pipeline_by_stage',
    type: 'pipeline_chart',
    title: 'Pipeline by Stage',
    description: 'count + deal value',
    icon: 'bar_chart',
    color: 'violet',
    layout: 'full',
    data: { items: pipelineByStage },
  });

  // ── Widget 6: Stuck deals ────────────────────────────────────
  const stuckDeals = Array.isArray(data?.stuckDeals) ? data.stuckDeals : [];
  widgets.push({
    id: 'stuck_deals',
    type: 'list',
    title: 'Stuck Deals (7+ days in same stage)',
    icon: 'alert',
    color: 'amber',
    layout: 'half',
    data: { items: stuckDeals, variant: 'warning' },
  });

  // ── Widget 7: Loss reason breakdown ──────────────────────────
  const lossReasons = Array.isArray(data?.lossReasonBreakdown ?? data?.lossReasons)
    ? (data?.lossReasonBreakdown ?? data?.lossReasons)
    : [];
  widgets.push({
    id: 'loss_reason_breakdown',
    type: 'pie_chart',
    title: 'Loss Reason Breakdown',
    icon: 'pie_chart',
    color: 'red',
    layout: 'half',
    data: { items: lossReasons },
  });

  // ── Widget 8: Overdue follow-ups (team) ──────────────────────
  const overdue = Array.isArray(data?.overdueFollowUps ?? data?.overdueFollowups)
    ? (data?.overdueFollowUps ?? data?.overdueFollowups)
    : [];
  widgets.push({
    id: 'overdue_follow_ups_team',
    type: 'table',
    title: 'Overdue Follow-ups (Team)',
    icon: 'clock',
    color: 'red',
    layout: 'full',
    data: {
      items: overdue,
      showCount: true,
      columns: [
        { key: 'companyName', label: 'Company', color: 'primary' },
        { key: 'executiveName', label: 'Executive' },
        { key: 'followUpDate', label: 'Follow-up Date', color: 'red' },
      ],
    },
  });

  return widgets;
}

// ── Manager Dashboard ──────────────────────────────────────────────────────
export function ManagerDashboard() {
  const [datePreset, setDatePreset] = useState('last_30');
  const params = getDateRange(datePreset);

  const { data, isLoading } = useQuery({
    queryKey: ['dashboard', 'manager', datePreset],
    queryFn: () => analyticsApi.getManagerDashboard(params).then((r) => r.data?.data ?? r.data ?? {}),
    staleTime: 15_000,
    refetchInterval: 30_000,
    refetchOnWindowFocus: true,
    refetchOnMount: true,
  });

  const widgets = useMemo(() => buildManagerWidgets(data ?? {}), [data]);

  if (isLoading) {
    return <div className="flex items-center justify-center h-64"><Spinner size={24} /></div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between flex-wrap gap-2">
        <div>
          <h1 className="page-title">Sales Manager Dashboard</h1>
          <p className="text-sm text-slate-500 mt-1">Team performance &amp; pipeline overview</p>
        </div>
        <span className="text-xs bg-green-500/10 border border-green-500/20 text-green-400 px-3 py-1 rounded-full font-medium">
          Full team visibility
        </span>
      </div>

      <DateFilterBar value={datePreset} onChange={setDatePreset} />
      <WidgetGrid widgets={widgets} />
    </div>
  );
}
