'use client';

import { useState, useEffect, useRef, useMemo } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { activitiesApi, leadsApi, opportunitiesApi, usersApi } from '../../../lib/api';
import { Avatar, Spinner, EmptyState } from '../../../components/ui';
import { getInitials, timeAgo } from '../../../lib/utils';
import { usePermissions } from '../../../lib/rbac';
import { useAuthStore } from '../../../store/authStore';
import {
  CheckSquare, Phone, MessageSquare, Mail, Calendar, Search, Plus, X,
  Video, RefreshCw, User, List, Clock, ChevronDown,
} from 'lucide-react';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import toast from 'react-hot-toast';

// â”€â”€ Types â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
type ActivityType = 'call' | 'meeting' | 'email' | 'note' | 'whatsapp' | 'demo' | 'follow_up';

type ActivityFormData = {
  type: ActivityType;
  activityDate: string;
  duration: string;
  linkedToType: 'lead' | 'opportunity';
  leadId: string;
  opportunityId: string;
  outcome: string;
  nextActionDate: string;
  notes: string;
  description: string;
};

// â”€â”€ Schema â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
const activitySchema = yup.object({
  type: yup.mixed<ActivityType>()
    .oneOf(['call','meeting','email','note','whatsapp','demo','follow_up'])
    .required('Activity type is required'),
  activityDate: yup.string().required('Date & time is required')
    .test('not-future', 'Activity date cannot be in the future', v => !v ? false : new Date(v) <= new Date()),
  duration: yup.string().optional()
    .test('positive-int', 'Must be a positive whole number', v => !v || (Number.isInteger(Number(v)) && Number(v) > 0)),
  linkedToType: yup.mixed<'lead'|'opportunity'>().oneOf(['lead','opportunity']).required(),
  leadId: yup.string().optional(),
  opportunityId: yup.string().optional(),
  description: yup.string().optional(),
  outcome: yup.string().trim().required('Outcome is required').max(1000, 'Max 1000 characters'),
  nextActionDate: yup.string().required('Next action date is required')
    .test('future', 'Must be a future date', v => {
      if (!v) return false;
      const today = new Date(); today.setHours(0,0,0,0);
      return new Date(`${v}T00:00:00`) > today;
    }),
  notes: yup.string().optional().max(2000, 'Max 2000 characters'),
}).test('linked-to-required', 'Please link to a lead or opportunity', v => Boolean(v?.leadId || v?.opportunityId));

const defaultValues: ActivityFormData = {
  type: 'call', activityDate: '', duration: '', linkedToType: 'lead',
  leadId: '', opportunityId: '', description: '', outcome: '', nextActionDate: '', notes: '',
};

// â”€â”€ Constants â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
const ACTIVITY_TYPES = [
  { value: 'call',      label: 'Call',      icon: Phone,         color: 'blue',   bg: 'bg-blue-500/15',    text: 'text-blue-400'    },
  { value: 'email',     label: 'Email',     icon: Mail,          color: 'blue',   bg: 'bg-blue-500/15',    text: 'text-blue-400'    },
  { value: 'meeting',   label: 'Meeting',   icon: Calendar,      color: 'purple', bg: 'bg-purple-500/15',  text: 'text-purple-400'  },
  { value: 'demo',      label: 'Demo',      icon: Video,         color: 'green',  bg: 'bg-green-500/15',   text: 'text-green-400'   },
  { value: 'follow_up', label: 'Follow-up', icon: RefreshCw,     color: 'amber',  bg: 'bg-amber-500/15',   text: 'text-amber-400'   },
  { value: 'whatsapp',  label: 'WhatsApp',  icon: MessageSquare, color: 'green',  bg: 'bg-green-500/15',   text: 'text-green-400'   },
  { value: 'note',      label: 'Note',      icon: MessageSquare, color: 'gray',   bg: 'bg-slate-500/15',   text: 'text-slate-400'   },
];

// â”€â”€ Helpers â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
function getTypeMeta(type: string) {
  return ACTIVITY_TYPES.find(t => t.value === type)
    ?? { icon: CheckSquare, color: 'gray', bg: 'bg-slate-500/15', text: 'text-slate-400', label: type, value: type };
}

function isToday(dateStr: string) {
  if (!dateStr) return false;
  const d = new Date(dateStr), n = new Date();
  return d.getFullYear() === n.getFullYear() && d.getMonth() === n.getMonth() && d.getDate() === n.getDate();
}

function isThisWeek(dateStr: string) {
  if (!dateStr) return false;
  const d = new Date(dateStr), n = new Date();
  const start = new Date(n); start.setDate(n.getDate() - n.getDay()); start.setHours(0,0,0,0);
  const end   = new Date(start); end.setDate(start.getDate() + 7);
  return d >= start && d < end;
}

function isPastDate(dateStr: string) {
  if (!dateStr) return false;
  const today = new Date(); today.setHours(0,0,0,0);
  return new Date(`${dateStr}T00:00:00`) < today;
}

function formatActivityDate(dateStr: string) {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  const n = new Date();
  const yesterday = new Date(n); yesterday.setDate(n.getDate() - 1);
  const time = d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
  if (isToday(dateStr)) return `Today, ${time}`;
  if (d.toDateString() === yesterday.toDateString()) return `Yesterday, ${time}`;
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

function getNextActionDisplay(dateStr: string): { label: string; color: string } | null {
  if (!dateStr) return null;
  const today = new Date(); today.setHours(0,0,0,0);
  const d = new Date(`${dateStr}T00:00:00`);
  if (d.toDateString() === today.toDateString()) return { label: `${dateStr} (due)`, color: 'text-amber-400' };
  if (d < today) return { label: `${dateStr} (overdue)`, color: 'text-red-400' };
  return { label: dateStr, color: 'text-blue-400' };
}

function groupActivitiesByDate(activities: any[]) {
  const groups: Record<string, any[]> = {};
  activities.forEach(a => {
    const raw = a.activityDate || a.createdAt;
    const d   = new Date(raw);
    const n   = new Date();
    const yesterday = new Date(n); yesterday.setDate(n.getDate() - 1);
    let key: string;
    if (isToday(raw))                        key = 'Today';
    else if (d.toDateString() === yesterday.toDateString()) key = 'Yesterday';
    else key = d.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' });
    if (!groups[key]) groups[key] = [];
    groups[key].push(a);
  });
  return groups;
}

// â”€â”€ Activity Row â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
function ActivityRow({ activity }: { activity: any }) {
  const meta        = getTypeMeta(activity.type);
  const Icon        = meta.icon;
  const nextAction  = activity.nextActionDate ? getNextActionDisplay(activity.nextActionDate) : null;
  const isOverdue   = activity.nextActionDate && isPastDate(activity.nextActionDate);
  const linkedName  = activity.lead?.companyName ?? activity.opportunity?.opportunityName ?? null;
  const linkedType  = activity.leadId ? 'lead' : activity.opportunityId ? 'opportunity' : null;
  const linkedHref  = activity.leadId ? `/dashboard/leads/${activity.leadId}` : '/dashboard/opportunities';

  return (
    <div className="px-5 py-4 hover:bg-slate-800/30 transition-colors">
      <div className="flex items-start gap-3">
        <div className={`w-8 h-8 rounded-xl ${meta.bg} flex items-center justify-center flex-shrink-0 mt-0.5`}>
          <Icon size={15} className={meta.text} />
        </div>
        <div className="flex-1 min-w-0">
          {/* Top row */}
          <div className="flex items-start justify-between gap-2 flex-wrap">
            <div className="flex items-center gap-1.5 flex-wrap min-w-0">
              <span className={`text-xs font-semibold ${meta.text}`}>{meta.label}</span>
              {linkedName && (
                <>
                  <span className="text-xs text-slate-600">linked to</span>
                  <a href={linkedHref}
                    className="text-xs text-blue-400 hover:text-blue-300 font-medium truncate max-w-[180px]">
                    {linkedName}
                  </a>
                  {linkedType && (
                    <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-semibold
                      ${linkedType === 'lead' ? 'bg-blue-500/15 text-blue-400' : 'bg-purple-500/15 text-purple-400'}`}>
                      {linkedType === 'lead' ? 'Lead' : 'Opportunity'}
                    </span>
                  )}
                </>
              )}
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              {isOverdue && (
                <span className="text-[10px] font-semibold bg-red-500/15 text-red-400 border border-red-500/25 px-1.5 py-0.5 rounded-full">
                  Overdue
                </span>
              )}
              <span className="text-xs text-slate-500 whitespace-nowrap">
                {activity.activityDate ? formatActivityDate(activity.activityDate) : timeAgo(activity.createdAt)}
                {activity.duration ? ` Â· ${activity.duration} mins` : ''}
              </span>
            </div>
          </div>
          {/* Outcome */}
          {activity.outcome && (
            <p className="text-xs text-slate-300 mt-1.5 line-clamp-2">&ldquo;{activity.outcome}&rdquo;</p>
          )}
          {/* Footer */}
          <div className="flex items-center gap-3 mt-1.5 flex-wrap">
            {nextAction && (
              <span className={`text-[11px] ${nextAction.color}`}>
                Next action: {nextAction.label}
              </span>
            )}
            <span className="text-[11px] text-slate-600">
              Logged by: {activity.createdBy?.name ?? 'You'}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

// â”€â”€ Page â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
export default function ActivitiesPage() {
  const queryClient = useQueryClient();
  const permissions = usePermissions();
  const currentUser = useAuthStore(s => s.user);

  // View & filter state
  const [viewMode,              setViewMode]              = useState<'list'|'timeline'>('list');
  const [searchText,            setSearchText]            = useState('');
  const [debouncedSearch,       setDebouncedSearch]       = useState('');
  const [typeFilter,            setTypeFilter]            = useState('');
  const [dateFrom,              setDateFrom]              = useState('');
  const [dateTo,                setDateTo]                = useState('');
  const [loggedByFilter,        setLoggedByFilter]        = useState('');
  const [linkedToFilterId,      setLinkedToFilterId]      = useState('');
  const [linkedToFilterName,    setLinkedToFilterName]    = useState('');
  const [linkedToFilterQuery,   setLinkedToFilterQuery]   = useState('');
  const [debouncedLTFQ,         setDebouncedLTFQ]         = useState('');
  const [showLinkedFilter,      setShowLinkedFilter]      = useState(false);
  const [page,                  setPage]                  = useState(1);

  // Form state
  const [isCreateOpen,    setIsCreateOpen]    = useState(false);
  const [linkedSearch,    setLinkedSearch]    = useState('');
  const [debouncedLS,     setDebouncedLS]     = useState('');
  const [linkedDropOpen,  setLinkedDropOpen]  = useState(false);
  const [linkedDisplay,   setLinkedDisplay]   = useState('');
  const linkedSearchRef  = useRef<HTMLDivElement>(null);
  const linkedFilterRef  = useRef<HTMLDivElement>(null);

  // Debounces
  useEffect(() => { const t = setTimeout(() => setDebouncedSearch(searchText), 300);   return () => clearTimeout(t); }, [searchText]);
  useEffect(() => { const t = setTimeout(() => setDebouncedLS(linkedSearch), 300);     return () => clearTimeout(t); }, [linkedSearch]);
  useEffect(() => { const t = setTimeout(() => setDebouncedLTFQ(linkedToFilterQuery), 300); return () => clearTimeout(t); }, [linkedToFilterQuery]);

  // Click-outside for dropdowns
  useEffect(() => {
    function handler(e: MouseEvent) {
      if (linkedSearchRef.current && !linkedSearchRef.current.contains(e.target as Node)) setLinkedDropOpen(false);
      if (linkedFilterRef.current && !linkedFilterRef.current.contains(e.target as Node)) setShowLinkedFilter(false);
    }
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const { register, handleSubmit, reset, watch, setValue, formState: { errors } } =
    useForm<ActivityFormData>({ defaultValues, resolver: yupResolver(activitySchema) as any, mode: 'onBlur' });

  const outcome = watch('outcome') || '';
  const notes   = watch('notes')   || '';

  // â”€â”€ RBAC base params â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const baseParams = permissions.canViewAllLeads ? {} : { assignedToMe: true };

  // â”€â”€ Stats (fetch wide, compute locally) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const { data: statsRaw } = useQuery({
    queryKey: ['activities-stats', baseParams],
    queryFn:  () => activitiesApi.list({ ...baseParams, limit: 500 }).then(r => r.data),
    staleTime: 60_000,
  });
  const allForStats = useMemo(() => (statsRaw?.data as any[]) ?? [], [statsRaw]);
  const stats = useMemo(() => ({
    today: allForStats.filter(a => isToday(a.activityDate || a.createdAt)).length,
    thisWeek: allForStats.filter(a => isThisWeek(a.activityDate || a.createdAt)).length,
    followUps: allForStats.filter(a => a.nextActionDate && isToday(a.nextActionDate)).length,
    overdue:   allForStats.filter(a => a.nextActionDate && isPastDate(a.nextActionDate)).length,
  }), [allForStats]);

  // â”€â”€ List query â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const listParams: any = { page, limit: 20, ...baseParams };
  if (debouncedSearch)  listParams.search      = debouncedSearch;
  if (typeFilter)       listParams.type        = typeFilter;
  if (dateFrom)         listParams.dateFrom    = dateFrom;
  if (dateTo)           listParams.dateTo      = dateTo;
  if (loggedByFilter)   listParams.createdById = loggedByFilter;
  if (linkedToFilterId) listParams.leadId      = linkedToFilterId;

  const { data: listData, isLoading } = useQuery({
    queryKey: ['activities', listParams],
    queryFn:  () => activitiesApi.list(listParams).then(r => r.data),
    placeholderData: prev => prev,
  });
  const activities  = (listData?.data as any[]) ?? [];
  const pagination  = listData?.pagination;
  const total       = pagination?.total ?? 0;
  const totalPages  = pagination?.totalPages ?? 1;
  const timelineGroups = useMemo(() => groupActivitiesByDate(activities), [activities]);

  // â”€â”€ Team members (manager/admin filter) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const { data: usersRaw } = useQuery({
    queryKey: ['team-members'],
    queryFn:  () => usersApi.list().then(r => r.data?.data ?? r.data ?? []),
    enabled:  permissions.canViewAllLeads,
    staleTime: 120_000,
  });
  const teamMembers = Array.isArray(usersRaw) ? usersRaw : [];

  // â”€â”€ Linked-to search for form â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const { data: lsLeadsRaw } = useQuery({
    queryKey: ['ls-leads', debouncedLS],
    queryFn:  () => leadsApi.list({ search: debouncedLS, limit: 5, ...baseParams }).then(r => r.data?.data ?? []),
    enabled:  debouncedLS.length >= 1,
    staleTime: 10_000,
  });
  const { data: lsOppsRaw } = useQuery({
    queryKey: ['ls-opps', debouncedLS],
    queryFn:  () => opportunitiesApi.list({ search: debouncedLS, limit: 5, ...baseParams }).then(r => r.data?.data ?? r.data ?? []),
    enabled:  debouncedLS.length >= 1,
    staleTime: 10_000,
  });
  const lsLeads = Array.isArray(lsLeadsRaw) ? lsLeadsRaw : [];
  const lsOpps  = Array.isArray(lsOppsRaw)  ? lsOppsRaw  : [];

  // â”€â”€ Linked-to filter search â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const { data: flLeadsRaw } = useQuery({
    queryKey: ['fl-leads', debouncedLTFQ],
    queryFn:  () => leadsApi.list({ search: debouncedLTFQ, limit: 6, ...baseParams }).then(r => r.data?.data ?? []),
    enabled:  debouncedLTFQ.length >= 1 && showLinkedFilter,
    staleTime: 10_000,
  });
  const flLeads = Array.isArray(flLeadsRaw) ? flLeadsRaw : [];

  // â”€â”€ Create mutation â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const createMutation = useMutation({
    mutationFn: (payload: any) => activitiesApi.create(payload),
    onSuccess: () => {
      toast.success('Activity logged');
      queryClient.invalidateQueries({ queryKey: ['activities'] });
      queryClient.invalidateQueries({ queryKey: ['leads'] });
      queryClient.invalidateQueries({ queryKey: ['opportunities'] });
      queryClient.invalidateQueries({ queryKey: ['dashboard'] });
      closeForm();
    },
    onError: (e: any) => toast.error(e.response?.data?.message || 'Failed to log activity'),
  });

  // â”€â”€ Handlers â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  function onSubmit(values: ActivityFormData) {
    createMutation.mutate({
      type:          values.type,
      description:   values.outcome,
      outcome:       values.outcome,
      leadId:        values.linkedToType === 'lead'         ? values.leadId        || undefined : undefined,
      opportunityId: values.linkedToType === 'opportunity'  ? values.opportunityId || undefined : undefined,
      activityDate:  values.activityDate,
      nextActionDate:values.nextActionDate,
      duration:      values.duration ? parseInt(values.duration, 10) : undefined,
      notes:         values.notes || undefined,
    });
  }

  function selectLinked(type: 'lead'|'opportunity', id: string, name: string) {
    setValue('linkedToType', type);
    if (type === 'lead') { setValue('leadId', id); setValue('opportunityId', ''); }
    else                 { setValue('opportunityId', id); setValue('leadId', ''); }
    setLinkedDisplay(name);
    setLinkedSearch('');
    setLinkedDropOpen(false);
  }

  function closeForm() {
    setIsCreateOpen(false);
    reset(defaultValues);
    setLinkedDisplay('');
    setLinkedSearch('');
  }

  function clearFilters() {
    setSearchText(''); setTypeFilter(''); setDateFrom(''); setDateTo('');
    setLoggedByFilter(''); setLinkedToFilterId(''); setLinkedToFilterName('');
    setLinkedToFilterQuery(''); setPage(1);
  }

  const hasActiveFilters = !!(searchText || typeFilter || dateFrom || dateTo || loggedByFilter || linkedToFilterId);
  const linkedToError = (errors as any)?.['']?.message;

  // â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  return (
    <div className="space-y-5">

      {/* 1. PAGE HEADER */}
      <div className="flex items-start justify-between flex-wrap gap-3">
        <div>
          <h1 className="page-title">Activities</h1>
          <p className="text-sm text-slate-500 mt-1">Log and track every interaction with your leads and opportunities</p>
        </div>
        {permissions.canLogActivity && (
          <button className="btn-primary" onClick={() => setIsCreateOpen(true)}>
            <Plus size={14} /> Log Activity
          </button>
        )}
      </div>

      {/* 2. SUMMARY STATS STRIP */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-3">
        <div className="card p-4">
          <p className="text-xs text-slate-500 mb-1">Today</p>
          <p className="text-2xl font-bold text-slate-100">{stats.today}</p>
          <p className="text-xs text-slate-600 mt-0.5">activities logged</p>
        </div>
        <div className="card p-4">
          <p className="text-xs text-slate-500 mb-1">This week</p>
          <p className="text-2xl font-bold text-slate-100">{stats.thisWeek}</p>
          <p className="text-xs text-slate-600 mt-0.5">activities logged</p>
        </div>
        <div className="card p-4">
          <p className="text-xs text-slate-500 mb-1">Follow-ups due</p>
          <p className="text-2xl font-bold text-amber-400">{stats.followUps}</p>
          <p className="text-xs text-slate-600 mt-0.5">next action today</p>
        </div>
        <div className="card p-4">
          <p className="text-xs text-slate-500 mb-1">Overdue</p>
          <p className="text-2xl font-bold text-red-400">{stats.overdue}</p>
          <p className="text-xs text-slate-600 mt-0.5">past next action date</p>
        </div>
      </div>
      {permissions.canViewAllLeads && (
        <p className="text-xs text-slate-600 -mt-2 pl-1">
          Stats are scoped to the logged-in user for Executive. Manager/Admin see team-wide counts.
        </p>
      )}

      {/* 3. VIEW TOGGLE */}
      <div className="flex items-center gap-2">
        <button
          onClick={() => setViewMode('list')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors
            ${viewMode === 'list'
              ? 'bg-slate-800 border-white/20 text-slate-100'
              : 'bg-transparent border-white/10 text-slate-500 hover:border-white/20'}`}
        >
          <List size={13} /> List view
        </button>
        <button
          onClick={() => setViewMode('timeline')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors
            ${viewMode === 'timeline'
              ? 'bg-slate-800 border-white/20 text-slate-100'
              : 'bg-transparent border-white/10 text-slate-500 hover:border-white/20'}`}
        >
          <Clock size={13} /> Timeline view
        </button>
      </div>

      {/* 4. FILTERS */}
      <div className="space-y-2">
        {/* Row: search + date range + linked-to + exec filter */}
        <div className="flex flex-wrap gap-2 items-center">
          {/* Text search */}
          <div className="relative flex-1 min-w-[200px] max-w-xs">
            <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none" />
            <input
              className="input pl-8 h-9 text-xs w-full"
              placeholder="Search by outcome, notes, lead nameâ€¦"
              value={searchText}
              onChange={e => { setSearchText(e.target.value); setPage(1); }}
            />
          </div>

          {/* Date from */}
          <input
            type="date" className="input h-9 text-xs" title="From date"
            value={dateFrom} onChange={e => { setDateFrom(e.target.value); setPage(1); }}
          />
          {/* Date to */}
          <input
            type="date" className="input h-9 text-xs" title="To date"
            value={dateTo} onChange={e => { setDateTo(e.target.value); setPage(1); }}
          />

          {/* Linked to filter */}
          <div className="relative" ref={linkedFilterRef}>
            <button
              className={`flex items-center gap-1.5 input h-9 text-xs cursor-pointer min-w-[110px] ${linkedToFilterId ? 'text-blue-300' : ''}`}
              onClick={() => setShowLinkedFilter(v => !v)}
            >
              <span className="truncate max-w-[100px]">{linkedToFilterName || 'Linked to'}</span>
              {linkedToFilterId ? (
                <X size={11} className="text-slate-400 hover:text-red-400 ml-auto flex-shrink-0"
                  onClick={e => { e.stopPropagation(); setLinkedToFilterId(''); setLinkedToFilterName(''); setLinkedToFilterQuery(''); setPage(1); }} />
              ) : (
                <ChevronDown size={11} className="ml-auto flex-shrink-0" />
              )}
            </button>
            {showLinkedFilter && (
              <div className="absolute top-full left-0 mt-1 w-56 bg-slate-900 border border-white/10 rounded-xl shadow-xl z-40 p-2">
                <input
                  autoFocus
                  className="input h-8 text-xs w-full"
                  placeholder="Search leadâ€¦"
                  value={linkedToFilterQuery}
                  onChange={e => setLinkedToFilterQuery(e.target.value)}
                />
                <div className="mt-1 max-h-40 overflow-y-auto">
                  {flLeads.map((l: any) => (
                    <button key={l.id}
                      className="w-full text-left px-2 py-1.5 text-xs hover:bg-slate-800 rounded text-slate-300"
                      onClick={() => { setLinkedToFilterId(l.id); setLinkedToFilterName(l.companyName); setShowLinkedFilter(false); setPage(1); }}>
                      {l.companyName}
                    </button>
                  ))}
                  {linkedToFilterQuery.length >= 1 && flLeads.length === 0 && (
                    <p className="text-xs text-slate-600 px-2 py-2">No leads found</p>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Manager: filter by executive */}
          {permissions.canViewAllLeads && teamMembers.length > 0 && (
            <select className="input h-9 text-xs" title="Filter by executive"
              value={loggedByFilter} onChange={e => { setLoggedByFilter(e.target.value); setPage(1); }}>
              <option value="">All executives</option>
              {teamMembers.map((m: any) => <option key={m.id} value={m.id}>{m.name}</option>)}
            </select>
          )}

          {/* Clear all */}
          {hasActiveFilters && (
            <button className="text-xs text-slate-500 hover:text-slate-300 flex items-center gap-1" onClick={clearFilters}>
              <X size={11} /> Clear all
            </button>
          )}
        </div>

        {/* Type filter pills */}
        <div className="flex flex-wrap gap-1.5">
          {[{ value: '', label: 'All' }, ...ACTIVITY_TYPES].map(t => (
            <button key={t.value}
              onClick={() => { setTypeFilter(t.value); setPage(1); }}
              className={`px-3 py-1 rounded-full text-xs border transition-colors
                ${typeFilter === t.value
                  ? 'bg-blue-500/15 border-blue-500/40 text-blue-300'
                  : 'bg-slate-900 border-white/10 text-slate-400 hover:border-white/20'}`}>
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* 5. ACTIVITY LIST / TIMELINE */}
      <div className="card overflow-hidden">
        {isLoading ? (
          <div className="flex items-center justify-center py-20"><Spinner size={24} /></div>
        ) : activities.length === 0 ? (
          hasActiveFilters ? (
            <EmptyState
              icon={Search}
              title="No results found"
              description="Try changing your filters or search terms"
              action={
                <button className="btn-ghost text-xs" onClick={clearFilters}>
                  Clear filters
                </button>
              }
            />
          ) : (
            <EmptyState
              icon={CheckSquare}
              title="No activities yet"
              description="Start by logging your first activity with a lead or opportunity"
              action={
                permissions.canLogActivity ? (
                  <button className="btn-primary text-xs" onClick={() => setIsCreateOpen(true)}>
                    <Plus size={13} /> Log Activity
                  </button>
                ) : undefined
              }
            />
          )
        ) : viewMode === 'list' ? (
          /* LIST VIEW */
          <div className="divide-y divide-white/[0.04]">
            {activities.map(a => <ActivityRow key={a.id} activity={a} />)}
          </div>
        ) : (
          /* TIMELINE VIEW */
          <div className="p-5 space-y-6">
            {Object.entries(timelineGroups).map(([label, items]) => (
              <div key={label}>
                <div className="flex items-center gap-3 mb-3">
                  <p className="text-xs font-semibold text-slate-400 whitespace-nowrap">{label}</p>
                  <div className="flex-1 h-px bg-white/[0.04]" />
                  <span className="text-[10px] text-slate-600">{items.length} activit{items.length === 1 ? 'y' : 'ies'}</span>
                </div>
                <div className="space-y-1 pl-2 border-l border-white/[0.06]">
                  {items.map(a => <ActivityRow key={a.id} activity={a} />)}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* PAGINATION */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between">
          <span className="text-sm text-slate-500">{total} total activities</span>
          <div className="flex gap-1">
            {Array.from({ length: Math.min(totalPages, 5) }, (_, i) => i + 1).map(p => (
              <button key={p} onClick={() => setPage(p)}
                className={`w-8 h-8 rounded-lg text-xs font-medium transition-colors
                  ${p === page ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30' : 'text-slate-500 hover:text-slate-300 hover:bg-slate-800'}`}>
                {p}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* 6. LOG ACTIVITY MODAL */}
      {isCreateOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="bg-slate-900 border border-white/10 rounded-2xl w-full max-w-xl shadow-2xl max-h-[92vh] flex flex-col">
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-white/[0.06]">
              <h3 className="text-base font-semibold text-slate-100">Log Activity</h3>
              <button title="Close" className="text-slate-500 hover:text-slate-300" onClick={closeForm}>
                <X size={16} />
              </button>
            </div>

            {/* Scrollable body */}
            <div className="overflow-y-auto flex-1 px-6 py-4">
              <form id="activity-form" className="space-y-4" onSubmit={handleSubmit(onSubmit)}>

                {/* Row 1: Type + Linked To */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="label mb-1 block">Activity Type <span className="text-red-400">*</span></label>
                    <select className="input" {...register('type')} title="Activity type">
                      {ACTIVITY_TYPES.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
                    </select>
                    {errors.type && <p className="text-xs text-red-400 mt-1">{errors.type.message}</p>}
                  </div>
                  <div>
                    <label className="label mb-1 block">Linked To <span className="text-red-400">*</span></label>
                    <div className="relative" ref={linkedSearchRef}>
                      <input
                        className="input pr-7 text-sm"
                        placeholder="Search lead or opportunityâ€¦"
                        autoComplete="off"
                        value={linkedDisplay || linkedSearch}
                        onChange={e => {
                          setLinkedSearch(e.target.value);
                          setLinkedDisplay('');
                          setValue('leadId', '');
                          setValue('opportunityId', '');
                          setLinkedDropOpen(true);
                        }}
                        onFocus={() => { if (!linkedDisplay) setLinkedDropOpen(true); }}
                      />
                      {(linkedDisplay || linkedSearch) && (
                        <button type="button"
                          title="Clear linked record"
                          className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300"
                          onClick={() => { setLinkedDisplay(''); setLinkedSearch(''); setValue('leadId',''); setValue('opportunityId',''); }}>
                          <X size={12} />
                        </button>
                      )}
                      {linkedDropOpen && (lsLeads.length > 0 || lsOpps.length > 0) && (
                        <div className="absolute top-full left-0 right-0 mt-1 bg-slate-800 border border-white/10 rounded-xl shadow-xl z-50 max-h-52 overflow-y-auto">
                          {lsLeads.length > 0 && (
                            <>
                              <p className="px-3 pt-2 pb-1 text-[10px] text-slate-500 font-semibold uppercase tracking-wider">Leads</p>
                              {lsLeads.map((l: any) => (
                                <button key={l.id} type="button"
                                  className="w-full text-left px-3 py-2 text-xs hover:bg-slate-700 text-slate-200"
                                  onClick={() => selectLinked('lead', l.id, l.companyName)}>
                                  <span className="font-medium">{l.companyName}</span>
                                  {l.contactName && <span className="text-slate-500 ml-1">Â· {l.contactName}</span>}
                                </button>
                              ))}
                            </>
                          )}
                          {lsOpps.length > 0 && (
                            <>
                              <p className="px-3 pt-2 pb-1 text-[10px] text-slate-500 font-semibold uppercase tracking-wider">Opportunities</p>
                              {lsOpps.map((o: any) => (
                                <button key={o.id} type="button"
                                  className="w-full text-left px-3 py-2 text-xs hover:bg-slate-700 text-slate-200"
                                  onClick={() => selectLinked('opportunity', o.id, o.opportunityName ?? o.title)}>
                                  <span className="font-medium">{o.opportunityName ?? o.title}</span>
                                  {o.businessLine && <span className="text-slate-500 ml-1">Â· {o.businessLine}</span>}
                                </button>
                              ))}
                            </>
                          )}
                        </div>
                      )}
                    </div>
                    {linkedToError && <p className="text-xs text-red-400 mt-1">{linkedToError}</p>}
                  </div>
                </div>

                {/* Row 2: Date & Time + Duration */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="label mb-1 block">Date &amp; Time <span className="text-red-400">*</span></label>
                    <input className="input" type="datetime-local" {...register('activityDate')} title="Activity date and time" />
                    {errors.activityDate && <p className="text-xs text-red-400 mt-1">{errors.activityDate.message}</p>}
                  </div>
                  <div>
                    <label className="label mb-1 block">Duration (mins)</label>
                    <input className="input" type="number" min="1" step="1" placeholder="e.g. 30"
                      {...register('duration')} title="Duration in minutes" />
                    {errors.duration && <p className="text-xs text-red-400 mt-1">{errors.duration.message}</p>}
                  </div>
                </div>

                {/* Outcome */}
                <div>
                  <label className="label mb-1 block">Outcome <span className="text-red-400">*</span></label>
                  <textarea
                    className="input min-h-[96px]"
                    placeholder="What happened? e.g. Client interested, wants proposal by Fridayâ€¦"
                    maxLength={1000}
                    {...register('outcome')}
                  />
                  <p className="text-[10px] text-slate-600 mt-1 text-right">{outcome.length}/1000</p>
                  {errors.outcome && <p className="text-xs text-red-400 mt-1">{errors.outcome.message}</p>}
                </div>

                {/* Row 4: Next Action Date + Notes */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="label mb-1 block">Next Action Date <span className="text-red-400">*</span></label>
                    <input className="input" type="date" {...register('nextActionDate')} title="Next action date" />
                    {errors.nextActionDate && <p className="text-xs text-red-400 mt-1">{errors.nextActionDate.message}</p>}
                  </div>
                  <div>
                    <label className="label mb-1 block">Notes</label>
                    <input className="input" placeholder="Additional context (optional)"
                      maxLength={2000} {...register('notes')} title="Notes" />
                    {errors.notes && <p className="text-xs text-red-400 mt-1">{errors.notes.message}</p>}
                  </div>
                </div>

                {/* Logged By â€“ read-only */}
                <div>
                  <label className="label mb-1 block">Logged By</label>
                  <div className="input flex items-center gap-2 opacity-60 cursor-not-allowed">
                    <User size={13} className="text-slate-500 flex-shrink-0" />
                    <span className="text-sm text-slate-400">{currentUser?.name ?? 'You'}</span>
                  </div>
                </div>

                {/* Info note */}
                <p className="text-[11px] text-slate-600 bg-slate-950 rounded-lg px-3 py-2 leading-relaxed">
                  On save â€” system auto-updates parent lead/opportunity:{' '}
                  <span className="text-slate-500">last_contacted_date = today, follow_up_date = next action date.</span>{' '}
                  No second save needed.
                </p>
              </form>
            </div>

            {/* Footer */}
            <div className="flex gap-2 px-6 py-4 border-t border-white/[0.06]">
              <button type="button" className="btn-ghost flex-1" onClick={closeForm}>Cancel</button>
              <button type="submit" form="activity-form" className="btn-primary flex-1" disabled={createMutation.isPending}>
                {createMutation.isPending ? 'Savingâ€¦' : 'Save activity'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
// import { Badge, Avatar, Spinner, EmptyState } from '../../../components/ui';
